$(document).ready(function () {
    $("#toggle").click(function () {
        $("nav").slideToggle();
    });
});
